# RFID Summer Camp Project

## Features
- RFID based attendance
- Arduino Uno system
- Serial Monitor output

## How it works
Scan RFID card → Arduino reads UID → checks database → shows result

## Author
Student Project
